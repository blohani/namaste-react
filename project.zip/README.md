# Namaste React

/\*
Header
-logo
-nav items
Body
-Search

- Restaurant container
  - Restaurant Card
    -image
    -Rest name
    -star rating
    -cuisines
    -delivery time
    Footer
    -copyright
    -links
    \*/
