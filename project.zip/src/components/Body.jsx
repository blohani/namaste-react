/* eslint-disable react/react-in-jsx-scope */
import { RestCard } from "./RestaurantCard";
// import { restList } from "./../utils/MockData.js";
import { useState, useEffect } from "react";
import { Shimmer } from "./Shimmer";

const Body = () => {
  const [resList, setResList] = useState([]);
  const [filteredRes, setFilteredRes] = useState([]);
  const [searchValue, setSearchValue] = useState("");
  useEffect(() => {
    fetchData();
  }, []);
  async function fetchData() {
    const response = await fetch(
      // "https://www.zomato.com/webroutes/getPage?page_url=/ncr/insta-worthy&location=&isMobile=0"
      "https://thingproxy.freeboard.io/fetch/https://www.swiggy.com/dapi/restaurants/list/v5?lat=12.9351929&lng=77.62448069999999&page_type=DESKTOP_WEB_LISTING"
    );
    const data = await response.json();
    // const restApiData = data?.page_data?.sections?.SECTION_ENTITIES_DATA; // Zomato API
    const restApiData =
      data?.data?.cards[4]?.card?.card?.gridElements?.infoWithStyle
        ?.restaurants; // Swiggy API
    setResList(restApiData);
    setFilteredRes(restApiData);
    console.log("restApiData", restApiData);
  }

  if (resList.length === 0) {
    return <Shimmer />;
  }

  return (
    <div className="body">
      <div className="filter">
        <div className="search_box">
          <input
            name="search"
            id="search"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            type="text"
            placeholder="search..."
          />
          <button
            onClick={() => {
              let searchedList = resList.filter(
                (rest) =>
                  // rest.name.toLowerCase().includes(searchValue.toLowerCase()) // Zomato API
                  rest.info?.name
                    .toLowerCase()
                    .includes(searchValue.toLowerCase()) // Swiggy API
              );
              setFilteredRes(searchedList);
              console.log("searchedList", searchedList);
            }}
          >
            Search
          </button>
        </div>
        <button
          className="filter-btn"
          onClick={() => {
            let filteredRest = resList.filter((rest) => {
              // return rest.rating?.aggregate_rating < 4; // Zomato API
              return rest.info?.avgRating > 4.3; // Swiggy API
            });
            setFilteredRes(filteredRest);
            console.log("filteredRest", filteredRest);
          }}
        >
          Filter Restaurants
        </button>
      </div>
      <div className="rest-container">
        {filteredRes.map((rest) => (
          <RestCard key={rest.info?.id} resData={rest} />
        ))}
      </div>
    </div>
  );
};

export default Body;
