
import React from "react";
import SubHeading from "./SubHeading";

const Food = (foodBlock) =>{
    console.log("foodBlock", foodBlock);
    if(foodBlock.itemCards.length == 0)
        return null;

    return (
        <>
            {foodBlock?.title && <SubHeading title={foodBlock.title} /> }
        </>
    )
}

export default Food