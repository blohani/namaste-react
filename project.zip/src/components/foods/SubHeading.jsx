import React from "react";

const SubHeading = (title) =>{
    return (
        <h3>{title}</h3>
    )
}
export default SubHeading