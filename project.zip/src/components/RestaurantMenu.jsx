/* eslint-disable react/react-in-jsx-scope */

import React, { useEffect, useState } from "react";
import { Shimmer } from "./Shimmer";
import Food from "./foods/food";

const RestaurantMenu = () =>{
    const [restDetails, setRestDetails] = useState([]);
    const [restMenu, setRestMenu] = useState([]);
    useEffect(()=>{
        fetchRestaurantMenu();
    }, [])

    const fetchRestaurantMenu = async () => {
        const response = await fetch("https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=12.9351929&lng=77.62448069999999&restaurantId=587240");
        const json = await response.json();
        const data = json.data;
        const resDetails = data.cards[2].card?.card?.info;
        const resMenu = data.cards[4]?.groupedCard?.cardGroupMap?.REGULAR?.cards[2]?.card?.card;
        setRestDetails(resDetails);
        setRestMenu(resMenu);
    }

    const {name, avgRating, cuisines, costForTwoMessage} = restDetails;
    // const {categories} = restMenu;
    // const menuItems = [];
    // if(restMenu.categories){
    //     console.log("restMenu: ", restMenu);
    //     restMenu.categories.map((item)=>{
    //         menuItems.push(<h3>{item?.title}</h3>);
    //         item.itemCards.map((item)=>{
    //             menuItems.push(<li>{item?.card?.info?.name}</li>)
    //         });
    // });
    // console.log("menuItems: ", menuItems);
    // }
 const menus = restMenu?.itemCards || restMenu?.categories;

    return  restDetails.length == 0 ? <Shimmer /> : (
        <div className="rest_container">
            <h1 className="rest_name">{name}</h1>
            <h1 className="rest_details">Rating - {avgRating}, Cost - {costForTwoMessage}</h1>
            <h2>Menu</h2>
            <h2>Cuisines - {cuisines}</h2>
            {        
                menus?.map((category)=>{
                <Food foodBlock = {category} />
                    })
            }
        </div>
    )
}

export default RestaurantMenu