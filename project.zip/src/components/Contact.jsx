
const Contact = () =>{
    return (
        <div>
            <h1>Contact</h1>
            <h2>Contact description</h2>
        </div>
    )
}

export default Contact