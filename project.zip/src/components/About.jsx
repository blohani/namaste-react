
const About = () =>{
    return (
        <div>
            <h1>About</h1>
            <h2>About description</h2>
        </div>
    )
}

export default About