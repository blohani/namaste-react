export const CDN_URL =
  "https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_660/";
// "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_508,h_320,c_fill/";

export const LOGO_URL =
  // "https://seeklogo.com/images/F/foodx-online-food-ordering-system-logo-145CB16578-seeklogo.com.png";
  "https://www.logodesign.net/logo/smoking-burger-with-lettuce-3624ld.png";
export const API_URL =
  "https://www.zomato.com/webroutes/getPage?page_url=/ncr/insta-worthy&location=&isMobile=0";
